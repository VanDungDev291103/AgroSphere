create definer = root@localhost trigger after_post_hashtag_delete
    after delete
    on post_hashtags
    for each row
BEGIN
    UPDATE hashtags 
    SET post_count = post_count - 1
    WHERE id = OLD.hashtag_id;
END;

