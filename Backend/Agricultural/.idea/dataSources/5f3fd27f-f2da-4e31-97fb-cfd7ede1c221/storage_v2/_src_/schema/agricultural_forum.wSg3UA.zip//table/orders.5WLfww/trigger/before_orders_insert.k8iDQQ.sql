create definer = root@localhost trigger before_orders_insert
    before insert
    on orders
    for each row
BEGIN
  SET NEW.total_amount = NEW.subtotal + IFNULL(NEW.shipping_fee, 0) + IFNULL(NEW.tax_amount, 0) - IFNULL(NEW.discount_amount, 0);
END;

