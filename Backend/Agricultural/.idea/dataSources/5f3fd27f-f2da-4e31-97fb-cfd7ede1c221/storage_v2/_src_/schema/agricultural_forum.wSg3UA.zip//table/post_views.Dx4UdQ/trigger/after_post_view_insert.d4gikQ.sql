create definer = root@localhost trigger after_post_view_insert
    after insert
    on post_views
    for each row
BEGIN
    UPDATE forum_posts 
    SET view_count = view_count + 1
    WHERE id = NEW.post_id;
END;

