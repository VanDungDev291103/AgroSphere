create definer = root@localhost trigger feedback_after_change
    after insert
    on feedback
    for each row
BEGIN
    UPDATE market_place
    SET average_rating = (SELECT AVG(rating) FROM feedback WHERE product_id = NEW.product_id AND status = 'approved'),
        review_count = (SELECT COUNT(*) FROM feedback WHERE product_id = NEW.product_id AND status = 'approved')
    WHERE id = NEW.product_id;
END;

