create definer = root@localhost trigger orders_after_status_update
    after update
    on orders
    for each row
BEGIN
    IF NEW.status != OLD.status THEN
        INSERT INTO order_status_history (order_id, status, created_by)
        VALUES (NEW.id, NEW.status, NULL);
    END IF;
END;

