create definer = root@localhost trigger orders_after_confirm
    after update
    on orders
    for each row
BEGIN
    IF NEW.status = 'CONFIRMED' AND OLD.status = 'PENDING' THEN
        -- Giảm số lượng sản phẩm trong kho
        UPDATE market_place mp
        JOIN order_details od ON mp.id = od.product_id AND od.order_id = NEW.id
        SET mp.quantity = mp.quantity - od.quantity,
            mp.purchase_count = mp.purchase_count + od.quantity;
        
        -- Giảm số lượng biến thể sản phẩm nếu có
        UPDATE product_variants pv
        JOIN order_details od ON pv.id = od.variant_id AND od.order_id = NEW.id
        SET pv.quantity = pv.quantity - od.quantity;
    END IF;
END;

