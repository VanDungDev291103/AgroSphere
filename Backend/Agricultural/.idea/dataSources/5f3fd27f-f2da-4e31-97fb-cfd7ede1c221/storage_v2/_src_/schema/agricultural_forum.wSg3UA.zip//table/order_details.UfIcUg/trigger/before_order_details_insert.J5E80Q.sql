create definer = root@localhost trigger before_order_details_insert
    before insert
    on order_details
    for each row
BEGIN
  SET NEW.total_price = NEW.price * NEW.quantity - IFNULL(NEW.discount_amount, 0);
END;

