create definer = root@localhost trigger feedback_after_update
    after update
    on feedback
    for each row
BEGIN
    IF NEW.status != OLD.status OR NEW.rating != OLD.rating THEN
        UPDATE market_place
        SET average_rating = (SELECT AVG(rating) FROM feedback WHERE product_id = NEW.product_id AND status = 'approved'),
            review_count = (SELECT COUNT(*) FROM feedback WHERE product_id = NEW.product_id AND status = 'approved')
        WHERE id = NEW.product_id;
    END IF;
END;

