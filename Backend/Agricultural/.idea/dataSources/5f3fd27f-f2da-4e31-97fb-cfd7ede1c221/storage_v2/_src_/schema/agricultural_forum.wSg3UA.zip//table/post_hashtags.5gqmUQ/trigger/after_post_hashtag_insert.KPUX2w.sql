create definer = root@localhost trigger after_post_hashtag_insert
    after insert
    on post_hashtags
    for each row
BEGIN
    UPDATE hashtags 
    SET post_count = post_count + 1
    WHERE id = NEW.hashtag_id;
END;

