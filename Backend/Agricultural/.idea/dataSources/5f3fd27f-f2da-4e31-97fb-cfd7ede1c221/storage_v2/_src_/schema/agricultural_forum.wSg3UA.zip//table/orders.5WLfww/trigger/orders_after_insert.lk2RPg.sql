create definer = root@localhost trigger orders_after_insert
    after insert
    on orders
    for each row
BEGIN
    INSERT INTO order_status_history (order_id, status, created_by)
    VALUES (NEW.id, NEW.status, NEW.buyer_id);
END;

