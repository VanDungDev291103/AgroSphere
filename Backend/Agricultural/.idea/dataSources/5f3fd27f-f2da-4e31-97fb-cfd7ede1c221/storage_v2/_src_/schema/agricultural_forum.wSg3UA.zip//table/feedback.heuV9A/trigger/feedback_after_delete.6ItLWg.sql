create definer = root@localhost trigger feedback_after_delete
    after delete
    on feedback
    for each row
BEGIN
    UPDATE market_place
    SET average_rating = (SELECT AVG(rating) FROM feedback WHERE product_id = OLD.product_id AND status = 'approved'),
        review_count = (SELECT COUNT(*) FROM feedback WHERE product_id = OLD.product_id AND status = 'approved')
    WHERE id = OLD.product_id;
END;

