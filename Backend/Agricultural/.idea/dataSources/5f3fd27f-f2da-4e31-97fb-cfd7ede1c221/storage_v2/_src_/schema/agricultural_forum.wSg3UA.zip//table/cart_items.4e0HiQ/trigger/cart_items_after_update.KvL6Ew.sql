create definer = root@localhost trigger cart_items_after_update
    after update
    on cart_items
    for each row
BEGIN
    UPDATE cart SET
                    total_items = (SELECT SUM(quantity) FROM cart_items WHERE cart_id = NEW.cart_id),
                    subtotal = (SELECT SUM(quantity * unit_price) FROM cart_items WHERE cart_id = NEW.cart_id),
                    updated_at = NOW()
    WHERE id = NEW.cart_id;
END;

